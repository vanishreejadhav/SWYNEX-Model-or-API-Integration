"""
AI Text Summarizer (CLI)
-------------------------
Integrates a pretrained AI summarization model (facebook/bart-large-cnn via
Hugging Face Transformers) into a small command-line prototype.

Usage:
    python summarizer.py --text "Some long text to summarize..."
    python summarizer.py --file examples/example_input.txt
    python summarizer.py --file examples/example_input.txt --max-length 80 --min-length 20

No API key is required — the model runs locally on your machine.
"""

import argparse
import sys

from transformers import pipeline

DEFAULT_MODEL = "facebook/bart-large-cnn"


def load_summarizer(model_name: str = DEFAULT_MODEL):
    """Load and return a Hugging Face summarization pipeline."""
    print(f"Loading model '{model_name}' (this may take a moment the first time)...")
    return pipeline("summarization", model=model_name)


def summarize_text(summarizer, text: str, max_length: int = 130, min_length: int = 30) -> str:
    """Run the summarization pipeline on a block of text and return the summary string."""
    if not text or not text.strip():
        raise ValueError("Input text is empty. Please provide text to summarize.")

    result = summarizer(
        text,
        max_length=max_length,
        min_length=min_length,
        do_sample=False,
    )
    return result[0]["summary_text"]


def get_input_text(args: argparse.Namespace) -> str:
    """Resolve the input text from either --text or --file."""
    if args.text:
        return args.text
    if args.file:
        with open(args.file, "r", encoding="utf-8") as f:
            return f.read()
    raise ValueError("You must provide either --text or --file as input.")


def main():
    parser = argparse.ArgumentParser(
        description="Summarize text using a pretrained AI summarization model."
    )
    parser.add_argument("--text", type=str, help="Raw text to summarize.")
    parser.add_argument("--file", type=str, help="Path to a .txt file containing text to summarize.")
    parser.add_argument("--max-length", type=int, default=130, help="Maximum length of the summary (default: 130).")
    parser.add_argument("--min-length", type=int, default=30, help="Minimum length of the summary (default: 30).")
    parser.add_argument("--model", type=str, default=DEFAULT_MODEL, help=f"Hugging Face model to use (default: {DEFAULT_MODEL}).")

    args = parser.parse_args()

    try:
        input_text = get_input_text(args)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    summarizer = load_summarizer(args.model)
    summary = summarize_text(summarizer, input_text, args.max_length, args.min_length)

    print("\n----- ORIGINAL TEXT (first 300 chars) -----")
    print(input_text.strip()[:300] + ("..." if len(input_text.strip()) > 300 else ""))
    print("\n----- SUMMARY -----")
    print(summary)


if __name__ == "__main__":
    main()
